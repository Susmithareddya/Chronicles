import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Sparkles, MessageCircle, Calendar, TrendingUp } from "lucide-react";

interface Suggestion {
  id: string;
  type: "topic" | "follow-up" | "trending" | "urgent";
  title: string;
  description: string;
  category: string;
  impact: "high" | "medium" | "low";
}

interface SuggestionsPanelProps {
  suggestions: Suggestion[];
}

export function SuggestionsPanel({ suggestions }: SuggestionsPanelProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case "topic": return <Sparkles className="w-4 h-4 text-purple-500" />;
      case "follow-up": return <MessageCircle className="w-4 h-4 text-blue-500" />;
      case "trending": return <TrendingUp className="w-4 h-4 text-green-500" />;
      case "urgent": return <Calendar className="w-4 h-4 text-red-500" />;
      default: return <Sparkles className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "topic": return "New Topic";
      case "follow-up": return "Follow-up";
      case "trending": return "Trending";
      case "urgent": return "Time-sensitive";
      default: return type;
    }
  };

  const impactColors = {
    high: "bg-red-100 text-red-800 border-red-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    low: "bg-green-100 text-green-800 border-green-200"
  };

  return (
    <Card className="border-gray-200">
      <CardHeader className="pb-3">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-purple-500" />
          <CardTitle className="text-lg text-gray-900">AI Suggestions</CardTitle>
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            {suggestions.length} suggestions
          </Badge>
        </div>
        <p className="text-sm text-gray-600">Topics and questions to explore with the manager</p>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          {suggestions.map((suggestion) => (
            <div 
              key={suggestion.id}
              className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {getIcon(suggestion.type)}
                  <Badge variant="outline" className="text-xs bg-gray-50 text-gray-600 border-gray-200">
                    {getTypeLabel(suggestion.type)}
                  </Badge>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${impactColors[suggestion.impact]}`}
                  >
                    {suggestion.impact} impact
                  </Badge>
                </div>
              </div>
              
              <h4 className="font-medium text-gray-900 mb-1">{suggestion.title}</h4>
              <p className="text-sm text-gray-600 mb-2">{suggestion.description}</p>
              
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                  {suggestion.category}
                </Badge>
                <Button size="sm" variant="outline" className="h-7 text-xs">
                  Schedule Discussion
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}