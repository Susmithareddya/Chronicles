import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { AlertTriangle, Lightbulb, Plus } from "lucide-react";
import { Button } from "./ui/button";

interface MissingStory {
  id: string;
  title: string;
  category: string;
  priority: "high" | "medium" | "low";
  reasoning: string;
  suggestedQuestions: string[];
}

interface MissingStoriesSectionProps {
  missingStories: MissingStory[];
}

export function MissingStoriesSection({ missingStories }: MissingStoriesSectionProps) {
  const priorityColors = {
    high: "bg-red-100 text-red-800 border-red-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
    low: "bg-blue-100 text-blue-800 border-blue-200"
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-orange-500" />
        <h2 className="text-xl font-semibold text-gray-900">Knowledge Gaps Identified</h2>
        <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
          {missingStories.length} gaps found
        </Badge>
      </div>

      <div className="grid gap-4">
        {missingStories.map((missing) => (
          <Card key={missing.id} className="border-l-4 border-l-orange-400 border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-base text-gray-900">{missing.title}</CardTitle>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="outline" className="text-xs bg-gray-50 text-gray-600 border-gray-200">
                      {missing.category}
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${priorityColors[missing.priority]}`}
                    >
                      {missing.priority} priority
                    </Badge>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="flex items-center space-x-1">
                  <Plus className="w-3 h-3" />
                  <span>Schedule</span>
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <p className="text-sm text-gray-600 mb-3">{missing.reasoning}</p>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-1">
                  <Lightbulb className="w-3 h-3 text-blue-500" />
                  <span className="text-xs font-medium text-gray-700">Suggested Questions:</span>
                </div>
                <ul className="space-y-1 ml-4">
                  {missing.suggestedQuestions.map((question, index) => (
                    <li key={index} className="text-xs text-gray-600 flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      <span>{question}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}