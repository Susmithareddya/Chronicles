import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { StatusBadge, StoryStatus } from "./StatusBadge";
import { Calendar, Tag } from "lucide-react";

export interface Story {
  id: string;
  title: string;
  date: string;
  status: StoryStatus;
  tags: string[];
  summary: string;
  duration?: string;
}

interface StoryCardProps {
  story: Story;
  onClick?: () => void;
}

export function StoryCard({ story, onClick }: StoryCardProps) {
  return (
    <Card 
      className={`cursor-pointer hover:shadow-md transition-all duration-200 border-gray-200 ${
        onClick ? 'hover:scale-[1.01]' : ''
      }`}
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-base text-gray-900 mb-2">{story.title}</CardTitle>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>{story.date}</span>
              </div>
              {story.duration && (
                <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                  {story.duration}
                </span>
              )}
            </div>
          </div>
          <StatusBadge status={story.status} />
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{story.summary}</p>
        
        {story.tags.length > 0 && (
          <div className="flex items-center space-x-2">
            <Tag className="w-3 h-3 text-gray-400" />
            <div className="flex flex-wrap gap-1">
              {story.tags.map((tag, index) => (
                <Badge 
                  key={index} 
                  variant="outline" 
                  className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}