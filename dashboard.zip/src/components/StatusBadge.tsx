import { Badge } from "./ui/badge";

export type StoryStatus = "completed" | "draft" | "missing";

interface StatusBadgeProps {
  status: StoryStatus;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const statusConfig = {
    completed: {
      label: "✅ Completed",
      variant: "default" as const,
      className: "bg-green-100 text-green-800 border-green-200"
    },
    draft: {
      label: "🟡 Draft",
      variant: "secondary" as const,
      className: "bg-yellow-100 text-yellow-800 border-yellow-200"
    },
    missing: {
      label: "🔴 Missing",
      variant: "destructive" as const,
      className: "bg-red-100 text-red-800 border-red-200"
    }
  };

  const config = statusConfig[status];

  return (
    <Badge variant={config.variant} className={config.className}>
      {config.label}
    </Badge>
  );
}