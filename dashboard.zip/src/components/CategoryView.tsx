import { Button } from "./ui/button";
import { ArrowLeft } from "lucide-react";
import { StoryCard, Story } from "./StoryCard";
import { Category } from "./CategoryCard";

interface CategoryViewProps {
  category: Category;
  stories: Story[];
  onBack: () => void;
  searchQuery?: string;
}

export function CategoryView({ category, stories, onBack, searchQuery }: CategoryViewProps) {
  const filteredStories = searchQuery 
    ? stories.filter(story => 
        story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        story.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : stories;

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onBack}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </Button>
        
        <div className="flex items-center space-x-3">
          <div className="text-2xl">{category.icon}</div>
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">{category.title}</h1>
            <p className="text-gray-600">{category.description}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStories.map((story) => (
          <StoryCard key={story.id} story={story} />
        ))}
      </div>

      {filteredStories.length === 0 && searchQuery && (
        <div className="text-center py-12">
          <p className="text-gray-500">No stories found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
  );
}