import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ChevronRight } from "lucide-react";

export interface Category {
  id: string;
  title: string;
  description: string;
  storyCount: number;
  completedCount: number;
  draftCount: number;
  missingCount: number;
  icon: string;
}

interface CategoryCardProps {
  category: Category;
  onClick: () => void;
}

export function CategoryCard({ category, onClick }: CategoryCardProps) {
  const completionRate = Math.round((category.completedCount / category.storyCount) * 100);

  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-[1.02] border-gray-200"
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">{category.icon}</div>
            <div>
              <CardTitle className="text-lg text-gray-900">{category.title}</CardTitle>
              <p className="text-sm text-gray-600 mt-1">{category.description}</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Total Stories</span>
            <span className="font-semibold text-gray-900">{category.storyCount}</span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-900 h-2 rounded-full transition-all duration-300"
              style={{ width: `${completionRate}%` }}
            ></div>
          </div>
          
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">{completionRate}% Complete</span>
            <div className="flex space-x-2">
              {category.completedCount > 0 && (
                <Badge variant="outline" className="text-green-700 border-green-200 bg-green-50">
                  {category.completedCount} ✅
                </Badge>
              )}
              {category.draftCount > 0 && (
                <Badge variant="outline" className="text-yellow-700 border-yellow-200 bg-yellow-50">
                  {category.draftCount} 🟡
                </Badge>
              )}
              {category.missingCount > 0 && (
                <Badge variant="outline" className="text-red-700 border-red-200 bg-red-50">
                  {category.missingCount} 🔴
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}