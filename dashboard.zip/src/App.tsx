import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { CategoryCard, Category } from "./components/CategoryCard";
import { CategoryView } from "./components/CategoryView";
import { MissingStoriesSection } from "./components/MissingStoriesSection";
import { SuggestionsPanel } from "./components/SuggestionsPanel";
import { categories, stories, missingStories, suggestions } from "./data/mockData";

type View = "dashboard" | "category";

export default function App() {
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Load ElevenLabs ConvAI widget script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/@elevenlabs/convai-widget-embed';
    script.async = true;
    script.type = 'text/javascript';
    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category);
    setCurrentView("category");
  };

  const handleBackToDashboard = () => {
    setCurrentView("dashboard");
    setSelectedCategory(null);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const filteredCategories = searchQuery
    ? categories.filter(category =>
        category.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        category.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        stories[category.id]?.some(story =>
          story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          story.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
          story.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      )
    : categories;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ElevenLabs ConvAI Chatbot Styles */}
      <style>{`
        elevenlabs-convai {
          position: fixed !important;
          bottom: 20px !important;
          right: 20px !important;
          z-index: 9999 !important;
          width: 350px !important;
          height: 500px !important;
          border-radius: 12px !important;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2) !important;
          overflow: hidden !important;
        }
      `}</style>

      <Header onSearch={handleSearch} searchQuery={searchQuery} />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        {currentView === "dashboard" && (
          <div className="space-y-8">
            {/* Dashboard Overview */}
            <div className="space-y-2">
              <h1 className="text-3xl font-semibold text-gray-900">Knowledge Dashboard</h1>
              <p className="text-gray-600">
                Capturing and organizing critical knowledge from BMW's senior leadership team
              </p>
            </div>

            {/* Search Results or Categories */}
            {searchQuery ? (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-gray-900">
                  Search Results for "{searchQuery}"
                </h2>
                {filteredCategories.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredCategories.map((category) => (
                      <CategoryCard
                        key={category.id}
                        category={category}
                        onClick={() => handleCategoryClick(category)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-500">No categories or stories found matching "{searchQuery}"</p>
                  </div>
                )}
              </div>
            ) : (
              <>
                {/* Categories Grid */}
                <div className="space-y-4">
                  <h2 className="text-xl font-semibold text-gray-900">Knowledge Categories</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {categories.map((category) => (
                      <CategoryCard
                        key={category.id}
                        category={category}
                        onClick={() => handleCategoryClick(category)}
                      />
                    ))}
                  </div>
                </div>

                {/* Two Column Layout for Missing Stories and Suggestions */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2">
                    <MissingStoriesSection missingStories={missingStories} />
                  </div>
                  <div className="lg:col-span-1">
                    <SuggestionsPanel suggestions={suggestions} />
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {currentView === "category" && selectedCategory && (
          <CategoryView
            category={selectedCategory}
            stories={stories[selectedCategory.id] || []}
            onBack={handleBackToDashboard}
            searchQuery={searchQuery}
          />
        )}
      </main>

      {/* ElevenLabs ConvAI Chatbot Widget */}
      <elevenlabs-convai agent-id="agent_4301k60jbejbebzr750zdg463tr4"></elevenlabs-convai>
    </div>
  );
}