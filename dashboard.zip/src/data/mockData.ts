import { Category } from "../components/CategoryCard";
import { Story } from "../components/StoryCard";

export const categories: Category[] = [
  {
    id: "leadership",
    title: "Leadership Insights",
    description: "Management philosophy, team building, and decision-making frameworks",
    storyCount: 15,
    completedCount: 12,
    draftCount: 2,
    missingCount: 1,
    icon: "👑"
  },
  {
    id: "projects",
    title: "Project Histories", 
    description: "Major initiatives, launches, and transformation programs",
    storyCount: 23,
    completedCount: 18,
    draftCount: 3,
    missingCount: 2,
    icon: "🚗"
  },
  {
    id: "crisis",
    title: "Crisis Management",
    description: "Handling challenges, market downturns, and operational disruptions",
    storyCount: 8,
    completedCount: 6,
    draftCount: 1,
    missingCount: 1,
    icon: "🛡️"
  },
  {
    id: "suppliers",
    title: "Supplier Relations",
    description: "Key partnerships, negotiations, and supply chain strategies",
    storyCount: 18,
    completedCount: 14,
    draftCount: 2,
    missingCount: 2,
    icon: "🤝"
  },
  {
    id: "strategy",
    title: "Strategy Lessons",
    description: "Market analysis, competitive positioning, and long-term planning",
    storyCount: 12,
    completedCount: 9,
    draftCount: 2,
    missingCount: 1,
    icon: "🎯"
  },
  {
    id: "innovation",
    title: "Innovation & Technology",
    description: "R&D decisions, technology adoption, and future trends",
    storyCount: 10,
    completedCount: 7,
    draftCount: 1,
    missingCount: 2,
    icon: "💡"
  }
];

export const stories: Record<string, Story[]> = {
  leadership: [
    {
      id: "l1",
      title: "Building High-Performance Teams in Manufacturing",
      date: "March 15, 2024",
      status: "completed",
      tags: ["Team Building", "Manufacturing", "Performance"],
      summary: "Strategies for creating motivated teams in high-pressure manufacturing environments, including incentive structures and communication protocols.",
      duration: "45 min"
    },
    {
      id: "l2", 
      title: "Decision-Making During Market Uncertainty",
      date: "March 8, 2024",
      status: "completed",
      tags: ["Decision Making", "Market Analysis", "Risk Management"],
      summary: "Framework for making strategic decisions when market conditions are volatile, drawing from experiences during economic downturns.",
      duration: "52 min"
    },
    {
      id: "l3",
      title: "Leading Through Digital Transformation",
      date: "February 28, 2024", 
      status: "draft",
      tags: ["Digital Transformation", "Change Management", "Leadership"],
      summary: "Approaches to guiding traditional automotive teams through digital technology adoption and cultural shifts.",
      duration: "38 min"
    }
  ],
  projects: [
    {
      id: "p1",
      title: "Launch of i-Series Electric Vehicles",
      date: "March 20, 2024",
      status: "completed", 
      tags: ["Electric Vehicles", "Product Launch", "Innovation"],
      summary: "Complete story of the i-Series development from conception to market launch, including technical challenges and market positioning.",
      duration: "67 min"
    },
    {
      id: "p2",
      title: "Factory Automation Initiative 2019-2022",
      date: "March 12, 2024",
      status: "completed",
      tags: ["Automation", "Manufacturing", "Digital Transformation"],
      summary: "Multi-year project to modernize production lines with robotics and AI, including ROI analysis and workforce transition.",
      duration: "78 min"
    },
    {
      id: "p3",
      title: "Partnership with Chinese Tech Companies",
      date: "March 5, 2024",
      status: "draft",
      tags: ["Partnerships", "China", "Technology"],
      summary: "Strategic alliances formed in Chinese market for autonomous driving technology and local manufacturing.",
      duration: "44 min"
    }
  ],
  crisis: [
    {
      id: "c1",
      title: "Managing Supply Chain Disruption 2020-2021", 
      date: "March 18, 2024",
      status: "completed",
      tags: ["Supply Chain", "COVID-19", "Crisis Management"],
      summary: "How BMW navigated global supply shortages, including semiconductor crisis and logistics challenges during the pandemic.",
      duration: "89 min"
    },
    {
      id: "c2",
      title: "Recall Management and Brand Protection",
      date: "March 10, 2024",
      status: "completed",
      tags: ["Recall", "Brand Management", "Quality Control"],
      summary: "Handling product recalls while maintaining customer trust and brand reputation, including communication strategies.",
      duration: "56 min"
    }
  ],
  suppliers: [
    {
      id: "s1",
      title: "Negotiating Long-term Battery Supply Contracts",
      date: "March 22, 2024",
      status: "completed",
      tags: ["Battery Technology", "Contracts", "Electric Vehicles"],
      summary: "Strategic approach to securing battery supply for electric vehicle production, including risk mitigation and pricing strategies.",
      duration: "62 min"
    },
    {
      id: "s2",
      title: "Supplier Quality Standards Implementation",
      date: "March 14, 2024", 
      status: "completed",
      tags: ["Quality Standards", "Supplier Management", "Process Improvement"],
      summary: "Raising quality standards across supplier network while maintaining cost competitiveness and delivery schedules.",
      duration: "48 min"
    },
    {
      id: "s3",
      title: "Localizing Supply Chain in Emerging Markets",
      date: "March 6, 2024",
      status: "draft",
      tags: ["Emerging Markets", "Localization", "Supply Chain"],
      summary: "Strategy for building local supplier ecosystems in emerging markets to reduce costs and improve responsiveness.",
      duration: "41 min"
    }
  ],
  strategy: [
    {
      id: "st1",
      title: "Positioning BMW in the Luxury EV Market",
      date: "March 25, 2024",
      status: "completed",
      tags: ["Market Positioning", "Electric Vehicles", "Luxury Market"],
      summary: "Strategic decisions around BMW's electric vehicle positioning versus Tesla and other luxury competitors.",
      duration: "71 min"
    },
    {
      id: "st2",
      title: "Expansion Strategy for Asian Markets",
      date: "March 16, 2024",
      status: "completed",
      tags: ["Market Expansion", "Asia", "Strategy"],
      summary: "Long-term approach to growing BMW's presence in Asian markets, including local partnerships and product adaptation.",
      duration: "58 min"
    }
  ],
  innovation: [
    {
      id: "i1", 
      title: "Investment in Autonomous Driving Technology",
      date: "March 21, 2024",
      status: "completed",
      tags: ["Autonomous Driving", "R&D", "Technology Investment"],
      summary: "Decision-making process around autonomous driving R&D investments and technology partnership strategies.",
      duration: "64 min"
    },
    {
      id: "i2",
      title: "Sustainable Manufacturing Initiatives",
      date: "March 13, 2024",
      status: "draft",
      tags: ["Sustainability", "Manufacturing", "Innovation"],
      summary: "Implementation of circular economy principles and carbon-neutral manufacturing processes.",
      duration: "37 min"
    }
  ]
};

export const missingStories = [
  {
    id: "m1",
    title: "Supplier negotiations in China (2018-2020)",
    category: "Supplier Relations",
    priority: "high" as const,
    reasoning: "Critical period for establishing Chinese supplier relationships, but no recorded stories about negotiation strategies or cultural considerations.",
    suggestedQuestions: [
      "What were the key challenges in negotiating with Chinese suppliers?",
      "How did cultural differences impact negotiation strategies?", 
      "What lessons were learned about IP protection in supplier agreements?"
    ]
  },
  {
    id: "m2", 
    title: "Leadership succession planning insights",
    category: "Leadership Insights",
    priority: "medium" as const,
    reasoning: "No stories captured about developing next-generation leaders or succession planning methodologies.",
    suggestedQuestions: [
      "How do you identify high-potential leaders?",
      "What's your approach to preparing successors?",
      "How do you ensure knowledge transfer to new leaders?"
    ]
  },
  {
    id: "m3",
    title: "Market entry strategy for India",
    category: "Strategy Lessons", 
    priority: "medium" as const,
    reasoning: "BMW's India strategy appears underdocumented despite being a key emerging market.",
    suggestedQuestions: [
      "What were the key factors in BMW's India market approach?",
      "How did you adapt products for the Indian market?",
      "What partnerships were critical for success in India?"
    ]
  },
  {
    id: "m4",
    title: "Response to Tesla's market disruption",
    category: "Strategy Lessons",
    priority: "high" as const,
    reasoning: "Tesla's emergence as a major competitor likely required significant strategic responses, but this isn't captured.",
    suggestedQuestions: [
      "How did BMW initially respond to Tesla's market entry?",
      "What strategic changes were made to compete with Tesla?",
      "How did you balance traditional luxury positioning with EV innovation?"
    ]
  }
];

export const suggestions = [
  {
    id: "sg1",
    type: "urgent" as const,
    title: "Document regulatory compliance strategies",
    description: "With increasing global regulations on emissions and safety, capture knowledge about navigating regulatory landscapes.",
    category: "Strategy Lessons",
    impact: "high" as const
  },
  {
    id: "sg2", 
    type: "follow-up" as const,
    title: "Expand on digital transformation challenges",
    description: "The current draft story could be enhanced with specific examples of resistance management and change adoption metrics.",
    category: "Leadership Insights", 
    impact: "medium" as const
  },
  {
    id: "sg3",
    type: "topic" as const,
    title: "Knowledge management and organizational learning",
    description: "How did you establish systems for capturing and sharing institutional knowledge across BMW?",
    category: "Leadership Insights",
    impact: "high" as const
  },
  {
    id: "sg4",
    type: "trending" as const,
    title: "Sustainability as competitive advantage",
    description: "Current market trends suggest sustainability stories are highly valuable for future decision-making.",
    category: "Innovation & Technology",
    impact: "medium" as const
  },
  {
    id: "sg5",
    type: "topic" as const,
    title: "Managing global teams across time zones",
    description: "Practical insights on leading distributed teams and maintaining culture across global operations.",
    category: "Leadership Insights",
    impact: "medium" as const
  }
];