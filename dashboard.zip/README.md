
  # Corporate Knowledge Base Dashboard

  This is a code bundle for Corporate Knowledge Base Dashboard. The original project is available at https://www.figma.com/design/v3A6M5x6p2XBtv99x7LSWF/Corporate-Knowledge-Base-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  